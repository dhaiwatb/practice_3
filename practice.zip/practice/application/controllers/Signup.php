<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {
    public function index()
    {
        $this->load->view('signup');
    }
    public function checksignup()
    {
        $config = [
            'upload_path' => './uploads/',
            'allowed_types' => 'jpg|png|jpeg',
            //'file_name' => isset($this->session->userdata('user_name'))?$this->session->userdata('user_name'):'image'
        ];
        $this->load->library('upload',$config);
        $this->upload->initialize($config);
        $this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
        //print_r($this->form_validation->run('signup_form'));    die;
        if($this->form_validation->run('signup_form') && $this->upload->do_upload('userimage'))
        {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $firstname = $this->input->post('firstname');
            $lastname = $this->input->post('lastname');
            
            $data = $this->upload->data();
            $image_path = base_url('uploads/'.$data['raw_name'].$data['file_ext']);
/*            echo"<pre>";    
            print_r($data);var_dump("<br>".$image_path);die;*/
            $this->crudops->insertData($username,$password,$firstname,$lastname,$image_path);
            return redirect('home');
        }    
        else {
            $upload_error = $this->upload->display_errors();
            $this->load->view('signup',compact('upload_error'));
        }    
    }
}