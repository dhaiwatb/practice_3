<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Updateuserdata extends MY_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model("studentdetails");
    }
    public function index($id)
    {
        $this->load->view('updateprofile');        
    }
    public function displayData($id)
    {
        $data['user'] = $this->crudops->dispData($id);
        $this->load->view('updateprofile',$data);
    }
    public function updateUser($id)
    {
        $userid = $id;
        $username = $this->input->post('username'); 
        $password = $this->input->post('password');
        $firstname = $this->input->post('firstname');
        $lastname = $this->input->post('lastname');

        $this->crudops->updatedata($username,$password,$firstname,$lastname,$userid);
        
        return redirect('home');
    }
    public function adddetails()
    {   
        //$Cid = $this->input->post('countryid');
        $this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
        $userId = $this->session->userdata('user_id');
        $data['users'] = $this->crudops->dispdata($userId);
        $data['countries'] = $this->getCountry();        
        if($this->form_validation->run('student_info'))
        {
            $data['id'] = $this->session->userdata('user_id');
            $gender = $this->input->post('gender');
            $hobbies = $this->input->post('hobbies[]');
            $birthdate = $this->input->post('birthdate');
            $country = $this->input->post('country');
            $state = $this->input->post('state');
            $city = $this->input->post('city');

            $this->studentdetails->insertDetails($id,$gender,$hobby,$birthdate,$country,$state,$city);
            return redirect('allinfo');
        }
        else
        {
            $this->load->view('student_info',$data);
        }
    }
    public function getCountry()
    {
        $data['country'] = $this->studentdetails->getCountry();        
        return $data;
    }
    public function getState($Cid = '')
    {
        $Cid = $this->input->post('countryid');
        $data['states'] = $this->studentdetails->getState($Cid);
        return $data;
    }
    public function getCity($Sid = '')
    {
        $Sid = $this->input->post('stateid');
        $data['city'] = $this->studentdetails->getCity($Sid);
        return $data;
    }
    public function allinfo()
    {
        $data['id'] = $this->session->userdata('user_id');
        $data['gender'] = $this->input->post('gender');
        $data['hobbies'] = $this->input->post('hobbies[]');
        $data['birthdate'] = $this->input->post('birthdate');
        $data['country'] = $this->input->post('country');
        $data['state'] = $this->input->post('state');
        $data['city'] = $this->input->post('city');

        $this->load->view('allinfo',$data);
    }
    public function gender_check()
    {
        if(!$this->input->post('gender'))
        {
            $this->form_validation->set_message('gender',"please select one!");
            return false;
        }
        else
        {
            return true;
        }
    }
}