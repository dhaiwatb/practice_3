<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <?php 
      //echo link_tag('https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css');     
      echo link_tag('https://bootswatch.com/4/cerulean/bootstrap.min.css');     
      echo link_tag('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'); 
      echo link_tag('https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css');
    ?>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" type="text/javascript"></script>
    <script src="https://bootswatch.com/_vendor/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src = "https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
    <!--script src="https://bootswatch.com/_vendor/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script-->
    <script type="text/javascript" async="" src="https://ssl.google-analytics.com/ga.js"></script>    
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="<?=base_url('welcome');?>">Students'</a>  
  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?=base_url('home');?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <? /* if session available*/         if($this->session->userdata('user_name')):  ?>
       <li class="nav-item">        
        <span class="nav-item">Hello! </span>
        <a class="nav-link" href="<?=base_url('home');?>"><?php echo ucfirst($this->session->userdata('user_name')); ?></a>
      </li>
      <li class="nav-item">
        <a href="<?=base_url()."article"?>" class="nav-link">Add Article</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('logout/logoutuser');?>">Logout</a>
      </li>
      <?php /* if session not available */ else:      ?>
      
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('login');?>">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?=base_url('signup');?>">Register</a>
      </li>    
    <?php endif; ?>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="text" placeholder="Search">
      <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
<div class="container">
