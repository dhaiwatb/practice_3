<?php include('header.php'); ?>
    <h1>Logged out successfully</h1>
    <hr>
<?php include('footer.php'); ?>