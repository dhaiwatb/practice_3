<?php include 'header.php' ?>

<div class="row">
    <div class="col-lg-8">
        <h1>All details are added</h1>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-8">
        <p><?php echo $id; ?></p>
        <p><?php echo $gender;?></p>
        <p><?php  
            if(is_array($hobbies)){
                echo implode(",",$hobbies);
            }
        ?></p>
        <p><?php print_r($birthdate); ?></p>
        <p><?php echo $country; ?></p>
        <p><?php echo $state; ?></p>
        <p><?php echo $city; ?></p>
    </div>
</div>
<?php include 'footer.php' ?>