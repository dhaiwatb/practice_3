<?php include('header.php'); ?>

<div class="row">
    <div class="col-lg-12">
        <h1>Article List</h1>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-8 mx-auto">
        <table class="table">            
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Article title</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(is_array($articles) && count($articles)>0): ?>
                    <?php 
                        $n = 0;
                        foreach($articles as $article): 
                        $n++;
                    ?>
                        <tr>
                            <td><?=$n?></td>
                            <td><?=$article['title']?></td>
                            <td>
                                <a href="<?=base_url().'article/articlebyid/'.$article['id']?>" class="btn btn-primary">Edit</a>
                                <a href="<?=base_url().'article/deletearticle/'.$article['id']?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php 
                        endforeach; 
                    ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">
                            <p class="text-primary">
                                No articles found
                            </p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include('footer.php'); ?>